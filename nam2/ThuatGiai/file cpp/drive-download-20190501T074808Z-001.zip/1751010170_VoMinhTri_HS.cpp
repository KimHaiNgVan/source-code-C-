#include <iostream>
using namespace std;

const int MAX = 50;
int a [MAX];
int n;
int gan = 0, ss = 0, hv = 0;
void Nhap ()
{
	cout << "Nhap so luong phan tu cho mang: ";
	do
	{
		cin >> n;
		if (n <= 0 || n > MAX)
			cout << "Nhap sai! Nhap lai! ";
	} while (n <= 0 || n > MAX);
	cout << "Nhap " << n << " phan tu cho mang\n";
	for (int i = 0; i < n; i++)
	{
		cout << "a [" << i << "] = ";
		cin >> a [i];
	}
}
void Xuat ()
{
	for (int i = 0; i < n; i++)
		cout << a [i] << "\t";
	cout << endl;
}
void HoanDoi (int &x, int &y)
{
	int tmp = x;
	x = y;
	y = tmp;
}
void shift (int i, int n)
{
	gan++;
	int j = 2*i + 1;
	if (ss++, j >= n)
		return;
	if (ss++, j + 1 < n)
		if (ss++, a [j] < a [j + 1])
		{
			j++;
			gan++;
		}
	if (ss++, a [i] >= a [j])
		return;
	else
	{
		HoanDoi (a [i], a [j]);
		hv++;
		gan += 3;
		shift (j, n);
	}
}
void HeapS ()
{
	gan++;
	int i = n/2 - 1;
	while (ss++, i >= 0)
	{
		shift (i, n);
		gan++;
		i--;
	}
	gan++;
	int right = n - 1;
	while (ss++, right > 0)
	{
		HoanDoi (a[0], a [right]);
		hv++;
		gan += 4;
		right--;
		if (ss++, right > 0)
			shift (0, right);
	}
}
int main ()
{
	Nhap ();
	cout << "Mang hien tai la: \n";
	Xuat ();
	HeapS ();
	cout << "Mang sau khi sap xep: \n";
	Xuat ();
	cout << "So phep so sanh: " << ss << endl;
	cout << "So phep gan: " << gan << endl;
	cout << "So phep hoan vi: " << hv << endl;
	system ("pause");
}