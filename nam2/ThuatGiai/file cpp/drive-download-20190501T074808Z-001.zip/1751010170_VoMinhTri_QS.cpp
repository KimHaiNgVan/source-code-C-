#include <iostream>
using namespace std;

const int MAX = 50;
int a [MAX];
int n;
int gan = 0, ss = 0, hv = 0;
void Nhap ()
{
	cout << "Nhap so luong phan tu cho mang: ";
	do
	{
		cin >> n;
		if (n <= 0 || n > MAX)
			cout << "Nhap sai! Nhap lai! ";
	} while (n <= 0 || n > MAX);
	cout << "Nhap " << n << " phan tu cho mang\n";
	for (int i = 0; i < n; i++)
	{
		cout << "a [" << i << "] = ";
		cin >> a [i];
	}
}
void Xuat ()
{
	for (int i = 0; i < n; i++)
		cout << a [i] << "\t";
	cout << endl;
}
void HoanDoi (int &x, int &y)
{
	int tmp = x;
	x = y;
	y = tmp;
}
void QuickS (int left, int right)
{
	gan += 3;
	int x = a [(left + right)/2];
	int i = left;
	int j = right;
	while (ss++, i < j)
	{
		while (ss++, a [i] < x)
		{
			i++;
			gan++;
		}
		while (ss++, a [j] > x)
		{
			j--;
			gan++;
		}
		if (ss++, i <= j)
		{
			HoanDoi (a [i], a [j]);
			hv++;
			gan += 5;
			i++;
			j--;
		}
	}
	if (ss++, left < j)
		QuickS (left, j);
	if (ss++, i < right)
		QuickS (i, right);
}
int main ()
{
	Nhap ();
	cout << "Mang hien tai la: \n";
	Xuat ();
	cout << "Mang sau khi sap xep: \n";
	QuickS (0, n - 1);
	Xuat ();
	cout << "So phep so sanh: " << ss << endl;
	cout << "So phep gan: " << gan << endl;
	cout << "So phep hoan vi: " << hv << endl;
	system ("pause");
}