#include <iostream>
using namespace std;

const int MAX = 50;
int ss = 0, gan = 0;
void Nhap (int a[], int& n, int &k)
{
	cout << "Nhap so luong phan tu cho mang: ";
	do
	{
		cin >> n;
		if (n <= 0 || n > MAX)
			cout << "Nhap sai! Nhap lai! ";
	} while (n <= 0 || n > MAX);
	cout << "Nhap " << n << " phan tu cho mang\n";
	for (int i = 0; i < n; i++)
	{
		cout << "a [" << i << "] = ";
		cin >> a [i];
	}
	for(int i = 0; i < n; i++)
	{
		if (k < a[i])
			k = a[i];
	}
}
void Xuat (int a[], int n)
{
	for (int i = 0; i < n; i++)
		cout << a [i] << "\t";
	cout << endl;
}

void CountingS (int a[], int b [], int n, int k, int& kt)
{
	int c [20];
	gan++;
	for (int i = 0; ss++, i <= k; gan++, i++)
	{
		gan++;
		c [i] = 0;
	}
	gan++;
	for (int j = 0; ss++, j < n; gan++, j++)
	{
		c [a [j]]++;
		gan++;
	}
	gan += 2;
	kt = 0;
	for (int j = 0; ss++, j <= k; gan++, j++)
	{
		while (ss++, c [j] > 0)
		{
			b [kt++] = j;
			c [j]--;
			gan += 3;
		}
	}
}
int main ()
{
	int a [MAX];
	int b [MAX];
	int n;
	int k = 0;
	int kt;
	Nhap (a, n, k);
	cout << "Mang hien tai la: \n";
	Xuat (a, n);
	cout << "Mang sau khi sap xep: \n";
	CountingS (a, b, n, k, kt);
	Xuat (b, n);
	cout << "So phep so sanh: " << ss << endl;
	cout << "So phep gan: " << gan << endl;
	cout << "So phep hoan vi: " << 0 << endl;
	system ("pause");
}